package com.example.ProductImplementation.controller;


import com.example.ProductImplementation.controller.ProductController;
import com.example.ProductImplementation.model.Product;
import com.example.ProductImplementation.repository.ProductRepository;
import com.example.ProductImplementation.service.ProductService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.graphql.GraphQlTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.graphql.test.tester.GraphQlTester;

//@Import(ProductService.class)
@GraphQlTest(ProductController.class)
public  class ProductControllerGraphqlTest {
    @Autowired
    GraphQlTester graphQlTester;

@MockBean
ProductService productService;
    @Test
    void getAllProductsTest(){



        //language=GraphQl
   String  docs= """
        query {
            getAllProductsGraphql {
                              id
                             productNo
                              productName
          }
        }
        """;

         graphQlTester.document(docs)
                 .execute()
                 .path("getAllProductsGraphql")
                 .entityList(Product.class)
                 .hasSize(3);
    }


}
