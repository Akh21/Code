//package com.example.ProductImplementation.resolver;
//
//
//import com.example.ProductImplementation.model.Product;
//import com.example.ProductImplementation.service.ProductService;
//import com.graphql.spring.boot.test.GraphQLResponse;
//import com.graphql.spring.boot.test.GraphQLTest;
//import com.graphql.spring.boot.test.GraphQLTestTemplate;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.mock.mockito.MockBean;
//
//import static org.mockito.Mockito.doReturn;
//
//@GraphQLTest
//public class ProductQueryTest {
//    @Autowired
//    private GraphQLTestTemplate graphQLTestTemplate;
//
//    @MockBean
//    ProductService productService;
//@Test
//
//    public void getProduct(){
//
//        Product product=new Product();
//        product.setProductNo("123");
//        product.setProductName("macbook");
//        doReturn(product).when(productService).findAllProducts();
//
//        GraphQLResponse response=GraphQLTestTemplate.
//    }
//}
