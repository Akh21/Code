package com.example.ProductImplementation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductImplementationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductImplementationApplication.class, args);
	}

}
