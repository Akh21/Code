package com.example.ProductImplementation.controller;


import com.example.ProductImplementation.model.Product;
import com.example.ProductImplementation.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/product")
public class Controller {

    @Autowired
    private ProductService productService;

//    @GetMapping(produces = MediaType.TEXT_EVENT_STREAM_VALUE)
 @GetMapping()
    public Flux<Product> getAllProducts(){
        return productService.findAllProducts();
    }

    @GetMapping("/{productNo}")
    public Mono<Product> getByNo(@PathVariable String productNo){
        return productService.getByNo(productNo);
    }

    @PostMapping()
    Mono<Product> addProduct(@RequestBody Product product){
        return productService.addProduct(product);
    }

    @PatchMapping("/patch/{productNo}")
    public Mono<Product> updateProductByNo(@PathVariable String productNo,
                                           @RequestBody Product product){
     return productService.updateProductByNo(productNo, product);
    }

    @DeleteMapping("/{productNo}")
    public Mono<Product> deleteByNo(@PathVariable String productNo){
     return productService.deleteByNo(productNo);
    }
}
